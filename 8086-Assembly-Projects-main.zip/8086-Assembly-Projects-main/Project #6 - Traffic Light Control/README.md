# Traffic Light Control
## Table of Content
- [Traffic Light Control](#traffic-light-control)
  * [Abstract](#abstract)
  * [Author](#author)

## Abstract
Write a program to control the time of the traffic lights. The red and green signals should be
on for 3 minutes. The yellow signal should be on for 1 minute. 
## Author
[Mohammed El Battawty](https://github.com/MohamedBattawy)
